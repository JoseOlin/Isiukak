#include "mainwindow.h"
#include <QApplication>
#include "qcustomplot.h"
#include <cmath>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //Crear un widget tipo ventanas.
    QMainWindow win;
    //Creando un objeto QCustomPlot (es un tipo de widget).
    QCustomPlot cPlot;

    //El widget cPlot definido sera el widget principal de la ventana creada.
    win.setCentralWidget(&cPlot);

    //Creamos dos arreglos del tipo doble
    QVector<double> x(255);
    QVector<double> y(255);

    for(int ii=0; ii<255; ii++)
    {
        double x_T;
        x[ii] = (ii-127);//Para graficar valores de -127 a 127.
        x_T=x[ii]/15.5;

        if(x[ii]>=0)
        {
            y[ii]=exp(x_T)-1.0;
        }
        else {
            y[ii]=-(exp(-(x_T))-1.0);
        }
        //qDebug()<<"X[i]: "<<x[ii]<<"Y[i]: "<<y[ii]<<endl;
    }

    //Definir un grafico nuevo en el cPlot
    cPlot.addGraph();
    //Asignamos los datos a graficar
    cPlot.graph(0)->setData(x,y);
    cPlot.graph(0)->rescaleAxes();

    //Poner las etiquetas a los ejes.
    cPlot.xAxis->setLabel("x");
    cPlot.yAxis->setLabel("y");

    //Definir las posiciones y dimenciones de la VENTANA
    win.setGeometry(100,100,500,400);
    win.show();

    return a.exec();
}
